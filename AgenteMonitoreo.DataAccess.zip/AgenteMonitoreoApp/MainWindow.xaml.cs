using System;
using System.Linq;
using System.Windows;
using System.Collections.Generic;
using ClosedXML.Excel;
using PdfSharpCore.Pdf;
using PdfSharpCore.Drawing;
using System.IO;

namespace AgenteMonitoreoApp

{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            CargarFiltros();
        }

        private void CargarFiltros()
        {
            for (int i = DateTime.Now.Year - 5; i <= DateTime.Now.Year + 1; i++)
                cmbAnio.Items.Add(i);
            cmbAnio.SelectedItem = DateTime.Now.Year;

            for (int i = 1; i <= 12; i++)
                cmbMes.Items.Add(i);
            cmbMes.SelectedItem = DateTime.Now.Month;

            for (int i = 1; i <= 31; i++)
                cmbDia.Items.Add(i);
        }

        private void BtnBuscar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int anio = Convert.ToInt32(cmbAnio.SelectedItem);
                int mes = Convert.ToInt32(cmbMes.SelectedItem);
                var diaSeleccionado = cmbDia.SelectedItem?.ToString();

                using var db = new ContextoSQL();

                var query = db.ControlDocumentosPorHora
                    .Where(x => x.Anio == anio && x.Mes == mes);

                if (int.TryParse(diaSeleccionado, out int dia))
                    query = query.Where(x => x.Dia == dia);

                var lista = query.ToList();
                dataGrid.ItemsSource = lista;

                MessageBox.Show($"Registros encontrados: {lista.Count}", "Resultado");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error:{ex.Message}", "Error");
            }
        }

        private void BtnVerReporte_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Este botón mostrará el reporte en pantalla (vista previa pendiente).");
        }

        private void BtnExportarExcel_Click(object sender, RoutedEventArgs e)
        {
            var items = dataGrid.ItemsSource.Cast<ControlDocumentosPorHora>().ToList();
            var wb = new XLWorkbook();
            var ws = wb.Worksheets.Add("Reporte");
            ws.Cell(1, 1).InsertTable(items);
            var path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "ReporteHoras.xlsx");
            wb.SaveAs(path);
            MessageBox.Show($"Exportado correctamente a:{path}", "Excel");
        }

        private void BtnExportarPDF_Click(object sender, RoutedEventArgs e)
        {
            var items = dataGrid.ItemsSource.Cast<ControlDocumentosPorHora>().ToList();
            var doc = new PdfDocument();
            var page = doc.AddPage();
            var gfx = XGraphics.FromPdfPage(page);
            var font = new XFont("Verdana", 10);

            int y = 40;
            foreach (var item in items)
            {
                string line = $"{item.Anio}-{item.Mes}-{item.Dia} {item.Bodega} {item.TipoDocumento} {item.Estado}";
                gfx.DrawString(line, font, XBrushes.Black, new XRect(40, y, page.Width, page.Height), XStringFormats.TopLeft);
                y += 20;
            }

            var pdfPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "ReporteHoras.pdf");
            using var stream = File.Create(pdfPath);
            doc.Save(stream);
            MessageBox.Show($"Exportado correctamente a:{pdfPath}", "PDF");
        }

        private void BtnCerrar_Click(object sender, RoutedEventArgs e)
        {
            this.Close(); // cierra la ventana principal
        }
    }
}
